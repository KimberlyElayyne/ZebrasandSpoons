import React from "react";

const AboutSection = () => {
  const conditions = [
    {
      title: "Hypermobile Ehlers-Danlos Syndrome (hEDS)",
      description:
        "A connective tissue disorder characterized by joint hypermobility, skin hyperextensibility, and more.",
      color: "teal",
      symptoms: [
        "Joint hypermobility",
        "Chronic pain",
        "Easy bruising",
        "Skin hyperextensibility",
        "Fatigue",
      ],
    },
    {
      title: "Ehlers-Danlos Syndromes (EDS)",
      description:
        "A group of hereditary connective tissue disorders affecting collagen production and structure.",
      color: "teal",
      symptoms: [
        "Joint instability",
        "Cardiovascular issues",
        "Gastrointestinal problems",
        "Autonomic dysfunction",
      ],
    },
    {
      title: "Dissociative Identity Disorder (DID)",
      description:
        "A mental health condition characterized by the presence of multiple distinct personality states.",
      color: "peach",
      symptoms: [
        "Memory gaps",
        "Identity confusion",
        "Depersonalization",
        "Co-consciousness",
        "Emotional dysregulation",
      ],
    },
  ];

  return (
    <section>
      {conditions.map((condition, index) => (
        <div key={index}>
          <h2>{condition.title}</h2>
          <p>{condition.description}</p>
          <ul>
            {condition.symptoms.map((symptom, i) => (
              <li key={i}>{symptom}</li>
            ))}
          </ul>
        </div>
      ))}
    </section>
  );
};

export default AboutSection;
