import React from "react";
import "./styles.css";
import AboutSection from "./AboutSection";

export default function App() {
  return (
    <div className="App">
      <AboutSection />
    </div>
  );
}
